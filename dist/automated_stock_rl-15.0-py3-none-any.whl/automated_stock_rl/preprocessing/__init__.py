from .data_scraping import load_stock_data

__version__ = '3.0'
