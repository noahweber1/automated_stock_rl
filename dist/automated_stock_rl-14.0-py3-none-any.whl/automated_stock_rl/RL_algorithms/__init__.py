from .DQN import run_dqn_algorithm

__version__ = '3.0'
